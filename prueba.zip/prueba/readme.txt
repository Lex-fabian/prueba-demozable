 Prueba E2E: Flujo de compra en demoblaze.com

 INSTRUCCIONES DE EJECUCION

1. Paso uno. Se debe instalar Node.js si no lo tienes instalado
2. Paso dos. Abre una terminal en la carpeta del proyecto
3. Paso tres. Ejecuta  "npm install"  para instalar las dependencias
4. Paso cuatro. Para abrir Cypress ejecuta "npx cypress open"
5. Paso cinco. Selecciona el archivo de prueba "demoblaze_e2e.cy.js" y ejecutalo

 REQUISITOS
- Node.js
- Cypress


